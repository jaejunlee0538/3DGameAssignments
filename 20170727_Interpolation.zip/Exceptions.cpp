#include "stdafx.h"
#include "Exceptions.h"

namespace SGA {

}