#include "stdafx.h"
#include "ModelLoader.h"
namespace SGA {
	namespace ModelLoad {
	}
}