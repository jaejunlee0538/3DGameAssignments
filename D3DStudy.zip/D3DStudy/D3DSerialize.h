#pragma once
namespace SGA {

	std::ostream& operator<<(std::ostream& os, const D3DXMATRIX& mat);
}