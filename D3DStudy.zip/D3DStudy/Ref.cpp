#include "stdafx.h"
#include "Ref.h"
namespace SGA {
	Ref::Ref()
	{
	}


	Ref::~Ref()
	{
	}

}