#pragma once
namespace SGA {
	class Ref
	{
	public:
		Ref();
		virtual ~Ref();
	};
}
