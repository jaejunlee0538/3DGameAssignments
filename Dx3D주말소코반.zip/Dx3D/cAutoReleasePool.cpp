#include "StdAfx.h"
#include "cAutoReleasePool.h"


cAutoReleasePool::cAutoReleasePool(void)
{
}


cAutoReleasePool::~cAutoReleasePool(void)
{
}
